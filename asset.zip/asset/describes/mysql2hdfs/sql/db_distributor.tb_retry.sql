drop table if exists tb_retry;
create table tb_retry(id bigint,event STRING,status int) row format delimited fields terminated by "\t" STORED AS TEXTFILE;