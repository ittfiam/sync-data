drop table if exists tb_goods_sync_flag;
create table tb_goods_sync_flag(id int,flag int) row format delimited fields terminated by "\t" STORED AS TEXTFILE;