drop table if exists tb_phones;
create table tb_phones(distributor_id STRING,phone STRING,create_time date,update_time timestamp) row format delimited fields terminated by "\t" STORED AS TEXTFILE;