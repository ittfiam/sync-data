drop table if exists sph_counter;
create table sph_counter(counter_id int,max_id int) row format delimited fields terminated by "\t" STORED AS TEXTFILE;