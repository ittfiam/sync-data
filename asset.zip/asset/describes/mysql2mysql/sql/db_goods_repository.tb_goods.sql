drop table if exists tb_goods;
CREATE TABLE `tb_goods` (
  `goods_id` bigint(32)  AUTO_INCREMENT COMMENT '商品id',
  `goods_name` varchar(255)  DEFAULT '' COMMENT '商品名称',
  `goods_category_id` varchar(32)  DEFAULT '' COMMENT '商品类别id',
  `goods_brand` varchar(255)  DEFAULT '' COMMENT '商品品牌',
  `goods_code` varchar(255)  DEFAULT '' COMMENT '商品条码',
  `retail_goods_code` varchar(255)  DEFAULT '' COMMENT '零售商品条码',
  `retail_goods_name` varchar(255)  DEFAULT '' COMMENT '零售商品名称',
  `sale_spec` varchar(255)  DEFAULT '' COMMENT '售卖规格',
  `retail_spec` varchar(255)  DEFAULT '' COMMENT '零售规格',
  `unit_package_number` int(16)  DEFAULT '0' COMMENT '包装内商品数量',
  `unit_capacity` varchar(255)  DEFAULT '' COMMENT '商品容量',
  `rank` int(8)  DEFAULT '0' COMMENT '排序值',
  `goods_price` double(8,2)  DEFAULT '0.00' COMMENT '商品价格',
  `suggest_price` double(8,2)  DEFAULT '0.00' COMMENT '建议价格',
  `create_time` datetime  COMMENT '记录创建时间',
  `update_time` timestamp  DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '记录更新时间',
  PRIMARY KEY (`goods_id`),
  UNIQUE KEY `index_goods_code` (`goods_code`),
  UNIQUE KEY `index_retail_goods_code` (`retail_goods_code`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='商品信息表'