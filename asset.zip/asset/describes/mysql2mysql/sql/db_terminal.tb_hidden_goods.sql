drop table if exists tb_hidden_goods;
CREATE TABLE `tb_hidden_goods` (
  `distributor_id` varchar(32)  DEFAULT '' COMMENT '分销商id',
  `terminal_id` varchar(32)  DEFAULT '' COMMENT '终端id',
  `hidden_goods` text  COMMENT '屏蔽的商品id列表',
  `create_time` datetime  COMMENT '创建记录时间',
  `update_time` timestamp  DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新记录时间',
  PRIMARY KEY (`distributor_id`,`terminal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='配送点屏蔽终端商品表'